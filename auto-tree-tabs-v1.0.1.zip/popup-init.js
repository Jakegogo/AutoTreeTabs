// ===================
// Popup 初始化脚本
// ===================

/**
 * 初始化弹窗页面
 */
document.addEventListener('DOMContentLoaded', () => {
  // 初始化国际化
  initI18n();
});
